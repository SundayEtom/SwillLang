﻿#ifndef DEFS_HPP
#define DEFS_HPP

#include <iostream>
#include <fstream>
#include <sstream>
#include <cstdlib>
using namespace std;

// Tokens returned by scanner to parser
enum class Token{
	
	// Simple operators and punctuation tokens
	Minus, Plus, Times, Divide, Modulo, Semicolon, Open_Brace, Close_Brace,
	Open_Bracket, Close_Bracket, Concat,
	
	// Value types
	Null, Integer, Float, Character, String, Array, Object,
	
	// Language specials
	Swill_Doc, Copy_Block,
	
	// Broad categories
	Number, MathOp, StringOp, Punctuation, Character_String,
	Function, Variable,
	
	// Functions
	Print, PrintLn, Read, ReadLn
};

// Index of current character
int char_index = 0;

// Current line number of source text, starting from line 1.
int line_num = 1;

// Beginning of current line
int line_start = 0;

// Current source text line, a string
string line_string = "";

// Swill Block currently executing
int current_block = 0;

// Keep track of opened and closed braces
int brace_opened = 0;
int brace_closed = 0;

// Html output file stream
string output_file = "";


// Convert non-string values to string
template<typename T>
string tostring(T val){
	stringstream ss;
	string value;
		
	ss << val;	// Write val to string stream
	ss >> value;	// then read it back into value.
		
	return value;
}

// Print an error message and terminate program.
void print_error(string msg){
	int char_pos = (char_index-line_start+1);
	cout << "Error: Line " << line_num << ":" << char_pos << ": " << msg << endl;
	cout << "\t'" << line_string << "'\n";
	exit(EXIT_SUCCESS);
}

// Append text to html output file, if filename is given
bool overwrite = true;	// true if opening for the first time
template<typename T>
bool output(T data){
	if(output_file != ""){
		ofstream ofs;
		if(overwrite) ofs.open(output_file, ios_base::out);	// Overwrite any content
		else ofs.open(output_file, ios_base::app);	// Open in append mode
		
		if(ofs){
			if(overwrite) overwrite = false;	// Next time, we'll open in append mode
			ofs << data;
			ofs.close();
			return true;
		}
	}
	return false;
}


#endif
