﻿#ifndef VALUE_HPP
#define VALUE_HPP

#include <vector>
#include <list>
#include "defs.hpp"

// Value returned by factor()
class Value{
	private:
	Token type, category;
	string value;
	
	public:
	Value() : category{Token::Null}, type{Token::Null}, value{""}{}
	Value(Token c, Token t, string v) : category{c}, type{t}, value{v}{}
	
	void settype(Token t){ type = t; }
	void setcat(Token c){ category = c; }
	void setvalue(string v){ value = v; }
	
	Token gettype(){ return type; }
	Token getcat(){ return category; }
	string getvalue(){ return value; }
	
	bool match_token(Token tok){ return (type == tok); }
	bool match_cat(Token cat){ return (category == cat); }
	
	
	Value operator+(Value rhs){
		string return_value;
		if(
			rhs.match_cat(Token::Number)
			|| rhs.match_cat(Token::String)
			|| rhs.match_cat(Token::Character)
		){ return_value = tostring(stof(value) + stof(rhs.getvalue())); }
		else{ print_error("Illegal math operation: Addition."); }
		
		cout << "Math result is '" << return_value << "'\n";
		return Value(Token::Number, Token::Float, return_value);
	}
	
	
	Value operator*(Value rhs){
		string return_value;
		if(
			rhs.match_cat(Token::Number)
			|| rhs.match_cat(Token::String)
			|| rhs.match_cat(Token::Character)
		){ return_value = tostring(stof(value) * stof(rhs.getvalue())); }
		else{ print_error("Illegal math operation: Multiplication."); }
		
		return Value(Token::Number, Token::Float, return_value);
	}
	
	
	Value operator/(Value rhs){
		string return_value;
		if(
			rhs.match_cat(Token::Number)
			|| rhs.match_cat(Token::String)
			|| rhs.match_cat(Token::Character)
		){
			double divisor = stof(rhs.getvalue());
			if(divisor == 0) print_error("Division by zero!");
			return_value = tostring(stof(value) / divisor);
		}
		else{ print_error("Illegal math operation: Division."); }
		
		cout << "Math result is '" << return_value << "'\n";
		return Value(Token::Number, Token::Float, return_value);
	}
	
	
	Value operator%(Value rhs){
		string return_value;
		if(
			rhs.match_cat(Token::Number)
			|| rhs.match_cat(Token::String)
			|| rhs.match_cat(Token::Character)
		){
			int divisor = stoi(rhs.getvalue());
			if(divisor == 0) print_error("Division by zero!");
			return_value = tostring(stoi(value) % divisor);
		}
		else{ print_error("Illegal math operation: Modulo."); }
		
		return Value(Token::Number, Token::Integer, return_value);
	}
	
	
	Value operator-(Value rhs){
		string return_value;
		if(
			rhs.match_cat(Token::Number)
			|| rhs.match_cat(Token::String)
			|| rhs.match_cat(Token::Character)
		){ return_value = tostring(stof(value) - stof(rhs.getvalue())); }
		else{ print_error("Illegal math operation: Subtraction."); }
		
		return Value(Token::Number, Token::Float, return_value);
	}
	
	
	Value operator|(Value rhs){
		string return_value;
		return_value = (value + rhs.getvalue());
		return Value(Token::String, Token::String, return_value);
	}
	
	
	Value operator()(int start, int end){
		string return_value;
		
		if(type == Token::String){
			if((value.size() <= end) || (value.size() < start))
				print_error("String index out of range.");
			return_value = value.substr(start, end);
		}
		else{ print_error("Illegal math operation: Indexing with non-string type."); }
		
		return Value(Token::String, Token::String, return_value);
	}
};


// Simple LIFO stack for Value types.
class ValueStack{
	private:
	vector<Value> values;
	
	public:
	ValueStack(){}
	
	void push(Value value){
		values.push_back(value);
	}
	
	bool is_empty(){
		if(values.size() <= 0) return true;
		return false;
	}
	
	Value pop(){
		if(values.size() > 0){
			Value v = values.at(values.size()-1);
			values.erase(values.end()-1);
			return v;
		}
		return Value();
	}
};



// A FIFO stack, to hold tokens fetched but not used immediately.
class QueueStack{
	private:
	list<Value> values;
	
	public:
	QueueStack(){}
	
	void push(Value value){
		values.push_back(value);
	}
	
	bool is_empty(){
		if(values.size() <= 0) return true;
		return false;
	}
	
	Value pop(){
		if(values.size() > 0){
			Value v = values.front();
			values.pop_front();
			return v;
		}
		return Value();
	}
};

// scan(), factor(), term(), expression() and other parser helper routines will place
// and access scanned tokens here.
ValueStack VALUES;


// Tokens fetched but not used will be queued here. factor() will check
// here first before calling scan() for more tokens.
QueueStack QUEUE;


// Push objects of Value type to VALUES
void push(Value value){ VALUES.push(value); }


// Pop and return values from VALUES
Value pop(){ return VALUES.pop(); }


// Check if the stack is empty.
bool stack_empty(){ return VALUES.is_empty(); }


// Only if this values queue is empty will factor() call scan() for new tokens
bool queue_empty(){ return QUEUE.is_empty(); }


// Call this to place values on the QUEUE stack
void queue_value(Value value){ QUEUE.push(value); }


// This pops a value from the QUEUE and pushes it onto the VALUES stack.
// Return true if we found a value on queue, and false otherwise.
bool dequeue_value(){
	if(!queue_empty()){
		VALUES.push(QUEUE.pop());
		return true;
	}
	return false;
}

#endif
