﻿#include "scanner.hpp"

int main(){
	Scanner sc("test.sw");
	sc.parse();
	
	return 0;
}
