﻿#ifndef SCANNER_HPP
#define SCANNER_HPP


#include <iostream>
#include <fstream>
#include <cctype>
#include <string>
#include <cstdlib>
#include "defs.hpp"
#include "value.hpp"

using namespace std;

class Scanner{
	private:
	string filename;
	string text, token_string;
	int initial_index;
	char current_char, lookahead;
	
	string replace(string src, char match, char replacement){
		string to_return = "";
		for(char c : src){
			if(c == match) to_return += replacement;
			else to_return += c;
		}
		return to_return;
	}
	
	bool match(char tok){
		return (current_char == tok);
	}
	
	bool match_next(char tok){
		return (lookahead == tok);
	}
	
	bool match_braces(){
		return (brace_opened == brace_closed);
	}
	
	bool blocks_still_open(int number){
		if(brace_opened-brace_closed == number) return true;
		return false;
	}
	
	void save_parser_state(){
		// TODO
	}
	
	char nextchar(){
		if(char_index < text.size()){
			current_char = text[++char_index];
			lookahead = text[char_index+1];
		} else{
			current_char = lookahead = '\0';
			if(!match_braces()) print_error("Unmatched brace at end of file.");
		}
		
		if(current_char == '\n' && (char_index < text.size()-1)){
			line_num++;	// Keep track of current line. line_num is defined in defs.hpp
			line_start = char_index+1;	// Mark where this new source text line starts
			
			line_string = "";
			for(int i=line_start; i<text.size(); i++){
				if(text[i] == '\n') break;
				line_string += text[i];
			}
		}
		
		return current_char;
	}
	
	
	char pushback(){
		char pushed_back_char = current_char;
		
		if(char_index > initial_index){
			current_char = text[--char_index];
			lookahead = text[char_index+1];
		} else{
			current_char = text[initial_index];
			lookahead = text[initial_index+1];
		}
		
		if(pushed_back_char == '\n'){
			line_num--;
			int i;
			for(i=char_index; i>=initial_index; i--)
				if(text[i] == '\n') break;
			// When loop stops, either we are at a newline character, or we have
			// gone past initial_index (i.e. initial_index-1). So we need to increment i here, where current line starts.
			line_start = ++i;
			
			line_string = "";
			for(; i<text.size(); i++){
				if(text[i] == '\n') break;
				line_string += text[i];
			}
		}
		else if(char_index <= initial_index) line_num = 1;
		
		return current_char;
	}
	
	// build_token() constructs a Value object from tokens made available by scan() and 
	// pushes the object to the Values stack, where it can be accessed by any method that
	// needs it.
	// We need build_token() to be a macro so that its return statement will 
	// break us out of the while() loop of scan() below
	#define build_token(cat, type, val) push(Value(cat, type, val)); return; 
	
	
	public:
	Scanner(string file) : filename{file}, token_string{""}{
		
		string ext = filename.substr(filename.size()-3, 3);
		if(ext != ".sw"){
			cout << "The given file '" << filename << "' is not a Swill source file.\n";
			cout << "A Swill source file must end with lowercase '.sw'.\n";
			exit(EXIT_SUCCESS);
		}
		
		ifstream ifs(filename);
		if(ifs){
			// Source file exists; read all of its content and save in 'text'
			string line;
			while(!ifs.eof()){
				getline(ifs, line);
				// Replace every tab with a single space character
				text += line+'\n';	//replace(line, '\t', ' ')+'\n';
			}
			ifs.close();
		} else {
			cout << "Scanner error: File could not be opened.\n";
		}
	}
	
	int parse(){
		// Skip non-print characters that the file system may prepend to the source text
		// I noticed this while developing this program on the Mobile C Android app. This does
		// not mean this program won't port; it will.
		while(!isprint(nextchar()))
			;
		// In case we ever need to reset the scanner to the beginning of the source text,
		// we reset to this initial_index.
		initial_index = char_index;
		
		// Also set line_start to current character index
		line_start = char_index;
		
		// Read out current line for error diagnostics
		line_string = "";
		for(int i=line_start; i<text.size(); i++){
			if(text[i] == '\n') break;
			line_string += text[i];
		}
		
		// Use source file name as 'output_file', defined in defs.hpp
		output_file = filename+".html";
		
		do{
			if(match('s') && match_next('w') && (text[char_index+2] == '{')){
				if(match_braces()){	// Have all previous top-level blocks been closed?
					current_block++;	// Count this block; current_block is defined in defs.hpp
					nextchar();	// Move to 'w'
					nextchar();	// Move to '{'
					brace_opened++;	// We've entered top-level code block
					parse_block();
					nextchar();	// Skip block's closing brace
				} else print_error("Nested code blocks not allowed.");
			} else{
				output(current_char);
			}
		}while(nextchar());
			
		// Return number of Swill Blocks parsed successfully.
		return current_block;
	}
	
	
	void parse_block(){
		// A Swill block is a set of Swill statements, each ending with a semicolon.
		// Keep parsing statements until statement() returns Null, while counting completed
		// statements by semicolons.
		int statement_count = 0;
		statement();
		Value token = pop();
		
		while(!token.match_cat(Token::Null)){
			if(token.match_token(Token::Semicolon)) statement_count++;
			statement();
			token = pop();
		}
		
		// Even an empty block has 1 statement in it: 'Empty'.
		// This helps when a block contains only one actual statement,
		// and that statement is not terminated with a semicolon. Note that a semicolon is not
		// required for the 'last' statement in a block.
		if(!statement_count) statement_count = 1;
		
		push(token);	// Return 'Null' to parse(), indicating 'complete'.
		string s = (statement_count > 1)?" statements":" statement";
		cout << "\nEnd of block " << current_block << ". " << statement_count << s << " executed.\n";
	}
	
	
	void statement(){
		// Parse expressions until we find a termination semicolon, or until there
		// are no more expressions to parse.
		expression();
		Value token = pop();
		cout << "statement() gets '" << token.getvalue() << "' from expression().\n";
		
		while(!token.match_token(Token::Semicolon)){	// Note: call expression() first
			if(token.match_cat(Token::Null)) break;	// before this check, else only the first Swill Block may execute correctly.
			expression();
			token = pop();
			cout << "statement() gets '" << token.getvalue() << "' from expression().\n";
		}
		push(token);
	}
	
	
	// If 'process' is true, factor() will try to process or parse each token it
	// gets before returning a final value. Otherwise, it will simply return the
	// token without parsing.
	void factor(bool process = true){
		// Call scan() only if the queue stack is empty.
		// It won't make any difference to our caller.
		if(!dequeue_value()) scan();
		
		Value token = pop();	// Let's find out what token this is
		//push(token);
		
		if(process){
			switch(token.getcat()){
				case Token::Punctuation:{
					if(token.match_token(Token::Open_Bracket)){
						cout << "\nNested expression begins:\n";
						expression();
						token = pop();		// Only for debugging
						push(token);		// Only for debugging
						cout << "Nested expression ends:\n\n";
						cout << "factor() gets '" << token.getvalue() << "' after nested expression.\n";
					}
					else if(token.match_token(Token::Open_Brace)){
						/*
							This is tricky. Here, we have to copy the content of a raw html block to the
							output file. But if not careful, we may do so out of order: placing the raw
							html at the wrong place in the file in relation to expression()'s outputs to
							the same file. To guard against this, we have to wait until expression() has
							output html immediately preceding the current html block. How? We check what
							token is on top of the stack; if it is a semicolon, then expression() is about
							to write to the file. So we wait by pushing the opening brace of this block
							onto the stack and returning. The idea is that term(), which expects a token
							from us, will get that opening brace and, having no use for it, push it onto
							the QUEUE stack, thus allowing expression() to pop the semicolon already on the
							VALUES stack. expression() gets the semicolon and proceeds to write to output 
							(if it must). Since we are not yet at the end of the current Swill Block, factor()
							will be called again to fetch the next token. But we know that factor() has the lazy
							habit of calling scan() only if the QUEUE stack is empty. But our opening brace
							was pushed onto that stack by term(); so that brace will be dequeued by factor().
							At this point, there is no semicolon waiting on the VALUES stack; so we can
							now proceed to copy this raw html block's content to the output file, at the
							right place! When we're done, we call factor() recursively to fetch and push
							the next token after the html block. Impact on term() and expression()? None.
							As far as they are concerned, factor() behaves always as expected; no surprises.
						*/
						Value factors_last_push = pop();	// Get last token factor() actually pushed to term()
						push(factors_last_push);	// We've been peeping: don't get caught. Push it back to stack
					
						if(!factors_last_push.match_token(Token::Semicolon)){
							string html = "";
							while(nextchar()){	// OK. Top of stack is NOT a semicolon. Start copying raw html
								if(match('}')) brace_closed++;
								else if(match('{')) brace_opened++;
								if(blocks_still_open(1)) break;	// Are we at the end of html block?
								html += current_char;
							}
							output(html);	// Write raw html to output file
							factor();	// Call factor() recursively for the next token
						}
						else{
							// Return this opening brace: term() will simply queue it,
							// and we'll get it when next factor() is called.
							push(token);
						}
					}
					else push(token);
				} break;
			
				case Token::Character_String:{
					//if()
				} break;
			
				default: push(token); break;
			}
		}
		else{
			// No processing is required; push back the raw token and return
			push(token);
		}
		
		// Only for debugging: Remove all 3 lines below when done
		//token = pop();												// Line 1
		//push(token);												// Line 2
		cout << "factor() returns '" << token.getvalue() << "'\n";	// Line 3
	}
	
	
	
	void term(){
		factor();
		Value value = pop();
		push(value);	// Let this value wait on the stack: it may find use either here or in expression()
		cout << "term() gets '" << value.getvalue() << "' from factor() left on stack.\n";
		
		/*************************************************************************\
		* IMPORTANT:															  *
		* term() should concern itself only with tokens that are in the class: 	  *
		* { Semicolon, Times, Divide, Modulo }. Any token outside this class 	  *
		* should simply be allowed to remain on the top of the stack. This way,	  *
		* expression() handles the main task of parsing all expressions.		  *
		\*************************************************************************/
		
		if( // If factor() says
			value.match_cat(Token::Null)			// the token stream is empty,
			|| !value.match_token(Token::Semicolon) // or that this is not a semicolon
			|| 
			( // or that this is an arithmetic operator that is
			value.match_cat(Token::MathOp)
			&& !value.match_token(Token::Times)		// neither a multiplication sign, 
			&& !value.match_token(Token::Divide)	// nor a division sign
			&& !value.match_token(Token::Modulo)	// nor modulo
			)
		){ return; }	// simply return --- we have no business here
		
		factor();
		Value token = token = pop();
		cout << "term() gets '" << token.getvalue() << "' from factor().\n";
		
		// Forget the long name; the value of this variable will tell us whether the new
		// value 'token' is used in the while() loop or not. If 'token' is neither a
		// multiplication nor division sign (modulo is also division), then this variable
		// will remain false, else it will become true.
		bool is_multiply_or_divide_op = false;
		if(
			token.match_token(Token::Times)		// 'token' is either a multiplication, 
			|| token.match_token(Token::Divide)	// or a division
			|| token.match_token(Token::Modulo)	// or a modulo operator
		){ is_multiply_or_divide_op = true; }	// so set this variable to true.

		while(token.match_cat(Token::MathOp)){
			if(token.match_token(Token::Plus) || token.match_token(Token::Minus)){
				break;	// Let's leave addition and subtraction for expression()
			}
			
			factor();
			Value rhs = pop();
			Value lhs = pop();
			
			cout << "term() gets '" << rhs.getvalue() << "' from factor() as rhs.\n";
			cout << "term() pops '" << lhs.getvalue() << "' from stack as lhs.\n";
			
			if(token.match_token(Token::Times)) lhs = lhs * rhs;
			else if(token.match_token(Token::Divide)) lhs = lhs / rhs;
			else if(token.match_token(Token::Modulo)) lhs = lhs % rhs;
			
			push(lhs);
			cout << "term() pushes '" << lhs.getvalue() << "' to stack in while() loop.\n";
			
			factor();
			token = pop();
			cout << "term() gets '" << token.getvalue() << "' from factor() in while() loop.\n";
		}
		
		// If 'token' is not a MathOp for multiplication or division, then it was never used.
		// So place it on the QUEUE stack. That way, when expression() calls pop(), factor() will
		// dequeue and return 'token'. So expression() will have no idea that
		// term() had requested one too many tokens.
		if(!is_multiply_or_divide_op){ queue_value(token); }
		
		// Just for debugging
		value = pop();
		push(value);
		cout << "term() returns '" << value.getvalue() << "'.\n";
	}
	
	
	void expression(){
		term();
		Value value = pop();
		push(value);	// Let this value wait on the stack
		cout << "expression() gets '" << value.getvalue() << "' from term() left on stack.\n";
		
		// If factor() says the token stream is empty,
		if(value.match_cat(Token::Null)){ return; }	// simply return --- we have no business here
		
		term();
		Value token = pop();
		cout << "expression() gets '" << token.getvalue() << "' from term().\n";
		
		switch(token.getcat()){
			case Token::MathOp:{
				while(token.match_cat(Token::MathOp)){
					Value lhs = pop();	// Get left operand from stack, placed there by term()
			
					term();
					Value rhs = pop();
			
					cout << "expression() pops '" << lhs.getvalue() << "' from stack as lhs.\n";
					cout << "expression() gets '" << rhs.getvalue() << "' from term() as rhs.\n";
			
					if(token.match_token(Token::Plus)) lhs = lhs + rhs;
					else if(token.match_token(Token::Minus)) lhs = lhs - rhs;
			
					push(lhs);	// Save the result on the stack
					cout << "expression() pushes '" << lhs.getvalue() << "' to stack in while() loop.\n";
			
					term();
					token = pop();
					cout << "expression() gets '" << token.getvalue() << "' from term() in while() loop.\n";
				}
			} break;
			
			case Token::StringOp:{
				if(token.match_token(Token::Concat)){
					while(token.match_token(Token::Concat)){
						Value lhs = pop();	// Get left operand from stack, placed there by term()
			
						term();
						Value rhs = pop();
			
						cout << "expression() pops '" << lhs.getvalue() << "' from stack as lhs.\n";
						cout << "expression() gets '" << rhs.getvalue() << "' from term() as rhs.\n";
			
						lhs = lhs | rhs;
			
						push(lhs);	// Save the result on the stack
						cout << "expression() pushes '" << lhs.getvalue() << "' to stack in while() loop.\n";
			
						term();
						token = pop();
						cout << "expression() gets '" << token.getvalue() << "' from term() in while() loop.\n";
					}
				}
			} break;
		}
		// Restore final accumulated value from stack
		value = pop();
		
		// Only now may we write to output file. If we did so inside the loop, a given value
		// may have been written multiple times while evaluating the MathOps.
		// However, we must be sure that we are at the end of the current statement: 'token'
		// MUST contain a semicolon. Otherwise, we are not done parsing this statement; so
		// we push our value so far onto the stack and continue parsing.
		if(token.match_token(Token::Semicolon)){
			output("Line " + tostring(line_num) + ": Expression {" + value.getvalue() + "}");
			cout << "expression() writes '" << value.getvalue() << "' to output file.\n";
			push(token);	// Report back to statement
			cout << "expression() pushes '" << token.getvalue() << "' to stack.\n";
		}
		else push(value);
	}
	
	
	
	void scan(bool write_to_file=true){
		token_string = "";
		
		while(nextchar()){
			if(match('{')){
				brace_opened++;
				token_string = current_char;
				build_token(Token::Punctuation, Token::Open_Brace, token_string);
			} else if(match('}')){
				brace_closed++;
				token_string = current_char;
				// If this closing brace marks the end of this top-level block, we set this token's
				// category to Null, otherwise we Punctuation indicating we can continue parsing
				// this block.
				build_token((match_braces())?Token::Null:Token::Punctuation, Token::Close_Brace, token_string);
			} else if(match('(') || match(')')){
				token_string = current_char;
				Token token;
				if(match('(')) token = Token::Open_Bracket;
				else if(match(')')) token = Token::Close_Bracket;
				build_token(Token::Punctuation, token, token_string);
			} else if(isdigit(current_char) || match('.')){
				bool dot_matched = false, sign_matched = false, e_matched = false;
				// A number may start with a digit or a dot, and it may be in exponent notation (e.g. 123e-4)
				while(isdigit(current_char) || match('.') || match('-') || match('+') || match('e') || match('E')){
					if(match('.')){
						if(!dot_matched){
							dot_matched = true;
						}else break;		// Don't want to attach more than 1 dot to a number
					} else if(match('-') || match('+')){
						// The sign should come after 'e' or 'E' for exponent;
						// if not, stop scanning for this token
						if(!e_matched) break;
						
						 if(!sign_matched){
						 	sign_matched = true;
						 	if(!isdigit(lookahead)){
						 		token_string += current_char;
						 		print_error("Invalid number format: '"+token_string+"'");
						 	}
						 }else break;
					} else if(match('e') || match('E')){
						if(!e_matched){
							e_matched = true;
							if(!isdigit(lookahead) && !match_next('-') && !match_next('+')){
								token_string += current_char;
								print_error("Invalid number format: '"+token_string+"'");
							}
						}else break;
					}
					token_string += current_char;
					nextchar();		// Fetch next character token
				}
				pushback();	// Push back the character that breaks the loop
				
				// If the number ends with a dot, attach the digit 0
				if(dot_matched && token_string[token_string.size()-1] == '.')
					token_string += '0';
				
				// And if it starts with a dot, prepend the digit 0
				if(dot_matched && token_string[0] == '.')
					token_string = "0"+token_string;
				
				// If the number contains a dot or is in exponent format, set token type to Float;
				// otherwise set it to Integer.
				build_token(Token::Number, (dot_matched || e_matched)?Token::Float:Token::Integer, token_string);
			}
			else if(match('-') || match('+')){
				token_string += current_char;
				if(isdigit(lookahead)){
					nextchar();
					bool dot_matched = false;
					while(isdigit(current_char) || match('.')){
						if(match('.')){
							if(!dot_matched) dot_matched = true;
							else break;
						}
						token_string += current_char;
						nextchar();
					}
					pushback();
					build_token(Token::Number, (dot_matched)?Token::Float:Token::Integer, token_string);
				}else{
					Token token;
					if(token_string == "-") token = Token::Minus;
					else if(token_string == "+") token = Token::Plus;
					build_token(Token::MathOp, token, token_string);
				}
			}
			else if(isalpha(current_char) || match('_')){
				while(isalnum(current_char) || match('_')){
					token_string += current_char;
					nextchar();
				}
				pushback();
				if(token_string == "sw" && match_next('{')){
					print_error("Top-level blocks cannot nest.");
				} else if(token_string == "doc" && match_next('{')){
					// Ignore everything in this block; content will be considered as documentation
					// and written to a file named 'sw_doc.txt'
					token_string = "";
					nextchar();	// Move to opening brace '{'
					while(nextchar()){
						// If all braces except the top-level opening brace have been closed,
						// then we're at the end of the ignore{} block
						if(match('}')) brace_closed++;
						if(blocks_still_open(1)) break;
						token_string += current_char;
					}
					if(write_to_file){
						ofstream doc;
						doc.open("sw_doc.txt", ios_base::app);
						if(doc){
							doc << token_string << endl << endl;
							doc.close();
						}
						token_string = "";
					}
					else{ build_token(Token::Swill_Doc, Token::Swill_Doc, token_string); }
					
				} else {
					build_token(Token::Character_String, Token::Character_String, token_string);
				}
			}
			else if(match('"')){	// Read a string literal
				nextchar();
				while(!match('"')){
					if(match('\\')){	// Handle escape sequences
						nextchar();
						if(match('\\')) token_string += current_char;
						else if(match('t')) token_string += '\t';
						else if(match('n')) token_string += '\n';
						else if(match('a')) token_string += '\a';
						else if(match('"')) token_string += '"';
						else if(match('\'')) token_string += '\'';
						else if(match('b')) token_string += '\b';
						else if(match('r')) token_string += '\r';
						else if(match('f')) token_string += '\f';
						nextchar();
						continue;
					}
					token_string += current_char;
					nextchar();
				}
				// Don't pushback(), else you will be pushing back the terminating double quotes,
				// resulting in an infinite loop when fetching the next token which will be taken
				// as a string.
				build_token(Token::String, Token::String, token_string);
			}
			else if(match('/')){
				if( match_next('/')){
					// This is a single line comment. Skip all characters to the end of this line.
					while(!match('\n')) nextchar();
					// Don't return anything; just continue scanning for next valid token.
				} else if(match_next('*')){
					// This is a block or multi-line comment. Skip until the next '*' followed by '/'
					nextchar();	// Eat up the first star '*'...
					while(nextchar()){	// ... then scan until we find next '*' and '/'
						if(match('*') && match_next('/')){
							nextchar();
							break;
						}
					}
					// Return nothing; just continue scanning for next valid token
				} else {
					// Division sign
					token_string = current_char;
					build_token(Token::MathOp, Token::Divide, token_string);
				}
			}
			else if(match('*')){
				// Multiplication sign
				token_string = current_char;
				build_token(Token::MathOp, Token::Times, token_string);
			}
			else if(match('%')){
				// Modulo sign --- remainder after integer division
				token_string = current_char;
				build_token(Token::MathOp, Token::Modulo, token_string);
			}
			else if(match(';')){
				token_string = current_char;
				build_token(Token::Punctuation, Token::Semicolon, token_string);
			}
			else if(match('|')){
				token_string = current_char;
				build_token(Token::StringOp, Token::Concat, token_string);
			}
		}
		build_token(Token::Null, Token::Null, "");
	}
};

#endif
